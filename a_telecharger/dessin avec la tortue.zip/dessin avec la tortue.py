# Créé par Gregoire, le 13/01/2022 en Python 3.7
from random import randint
from turtle import *

def carre1():
    colormode(255)
    up()
    pensize(1)
    speed(0)
    hideturtle()
    goto(-200,200)
    down()
    rgb_r=randint(0,255)
    rgb_g=randint(0,255)
    rgb_b=randint(0,255)
    for i in range(1,400,1):
        forward(400-i)
        right(90.5)
        color(int(rgb_r),int(rgb_g),int(rgb_b))
        rgb_r=rgb_r+0.75
        rgb_g=rgb_g+0.5
        rgb_b=rgb_b+1
        if rgb_r>=254:
            rgb_r=0
        if rgb_g==255:
            rgb_g=0
        if rgb_b==255:
            rgb_b=0
    mainloop()


def carre2():
    colormode(255)
    up()
    pensize(1)
    speed(0)
    hideturtle()
    goto(0,0)
    down()
    rgb_r=randint(0,255)
    rgb_g=randint(0,255)
    rgb_b=randint(0,255)
    for i in range(1,400,1):
        forward(1+i)
        right(90.5)
        color(int(rgb_r),int(rgb_g),int(rgb_b))
        rgb_r=rgb_r+0.75
        rgb_g=rgb_g+0.5
        rgb_b=rgb_b+1
        if rgb_r>=254:
            rgb_r=0
        if rgb_g==255:
            rgb_g=0
        if rgb_b==255:
            rgb_b=0
    mainloop()



def etoile1():
    up()
    pensize(1)
    speed(0)
    hideturtle()
    goto(-200,50)
    down()
    for i in range(1,200,1):
        pencolor("red")
        forward(400)
        right(150)
    mainloop()


def etoile2():
    up()
    pensize(1)
    speed(0)
    hideturtle()
    goto(-200,50)
    down()
    for i in range(1,400,1):
        pencolor("red")
        forward(400-i)
        right(150)
    mainloop()


def etoile3():
    colormode(255)
    up()
    pensize(1)
    speed(0)
    hideturtle()
    goto(-200,50)
    down()
    rgb_r=randint(0,255)
    rgb_g=randint(0,255)
    rgb_b=randint(0,255)
    for i in range(1,300,1):
        color(int(rgb_r),int(rgb_g),int(rgb_b))
        forward(400-i)
        right(150)
        rgb_r=rgb_r+0.75
        rgb_g=rgb_g+0.5
        rgb_b=rgb_b+1
        if rgb_r>=254:
            rgb_r=0
        if rgb_g==255:
            rgb_g=0
        if rgb_b==255:
            rgb_b=0
    for i in range(1,900,1):
        undo()
    bye()


def etoile4():
    colormode(255)
    up()
    pensize(1)
    speed(0)
    hideturtle()
    goto(-250,50)
    down()
    rgb_r=randint(0,255)
    rgb_g=randint(0,255)
    rgb_b=randint(0,255)
    for i in range(1,400,1):
        color(int(rgb_r),int(rgb_g),int(rgb_b))
        forward(500-i)
        right(170)
        rgb_r=rgb_r+0.75
        rgb_g=rgb_g+0.5
        rgb_b=rgb_b+1
        if rgb_r>=254:
            rgb_r=0
        if rgb_g==255:
            rgb_g=0
        if rgb_b==255:
            rgb_b=0
    mailoop()

def etoile5():
    colormode(255)
    up()
    pensize(1)
    speed(0)
    hideturtle()
    goto(-250,50)
    down()
    rgb_r=randint(0,255)
    rgb_g=randint(0,255)
    rgb_b=randint(0,255)
    for i in range(1,400,1):
        color(int(rgb_r),int(rgb_g),int(rgb_b))
        forward(500)
        right(170)
        rgb_r=rgb_r+0.75
        rgb_g=rgb_g+0.5
        rgb_b=rgb_b+1
        if rgb_r>=254:
            rgb_r=0
        if rgb_g==255:
            rgb_g=0
        if rgb_b==255:
            rgb_b=0
    mailoop()

def octogne1 ():
    colormode(255)
    up()
    pensize(1)
    speed(0)
    hideturtle()
    goto(-200,200)
    down()
    rgb_r=randint(0,255)
    rgb_g=randint(0,255)
    rgb_b=randint(0,255)
    for i in range(1,500,1):
        forward(int(250-i))
        right(60.5)
        color(int(rgb_r),int(rgb_g),int(rgb_b))
        rgb_r=rgb_r+2
        rgb_g=rgb_g+0.75
        rgb_b=rgb_b+1
        if rgb_r>=254:
            rgb_r=0
        if rgb_g>=254:
            rgb_g=0
        if rgb_b>=254:
            rgb_b=0
    mainloop()


def octogne2():
    colormode(255)
    up()
    pensize(1)
    speed(0)
    hideturtle()
    goto(0,0)
    down()
    rgb_r=randint(0,255)
    rgb_g=randint(0,255)
    rgb_b=randint(0,255)
    for x in range(2):
        right(90)
        for i in range(1,200,1):
            circle(100-i,steps=8)
##            couleur(rgb_r,rgb_g,rgb_b)
            color(int(rgb_r),int(rgb_g),int(rgb_b))
            rgb_r=rgb_r+2
            rgb_g=rgb_g+0.75
            rgb_b=rgb_b+1
            if rgb_r>=254:
                rgb_r=0
            if rgb_g>=254:
                rgb_g=0
            if rgb_b>=254:
                rgb_b=0
    mainloop()
    print(rgb_r,rgb_g,rgb_b)



def couleur(rgb_r,rgb_g,rgb_b):
    rgb_r=rgb_r+2
    rgb_g=rgb_g+0.75
    rgb_b=rgb_b+1
    if rgb_r>=254:
        rgb_r=0
    if rgb_g>=254:
        rgb_g=0
    if rgb_b>=254:
        rgb_b=0
    color(int(rgb_r),int(rgb_g),int(rgb_b))

def octogne3():
    colormode(255)
    up()
    pensize(1)
    speed(0)
    hideturtle()
    goto(0,0)
    down()
    r=rgb_r=randint(0,255)
    g=rgb_g=randint(0,255)
    b=rgb_b=randint(0,255)
    right(90)
    for x in range(2):
        right(90)
        for x in range(2):
            right(180)
            rgb_r=r
            rgb_g=g
            rgb_b=b
            for i in range(1,100,1):
                circle(100-i,steps=8)
                color(int(rgb_r),int(rgb_g),int(rgb_b))
                rgb_r=rgb_r+2
                rgb_g=rgb_g+0.75
                rgb_b=rgb_b+1
                if rgb_r>=254:
                    rgb_r=0
                if rgb_g>=254:
                    rgb_g=0
                if rgb_b>=254:
                    rgb_b=0
    mainloop()