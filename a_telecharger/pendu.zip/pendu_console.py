# Créé par Gregoire, le 20/09/2022 en Python 3.7

"""jeux du pendu, """

from random import *
import unidecode # pour l'installe taper = pip install Unidecode , dans la console/cmd


print("")
print("         #####################################")
print("         ##                                 ##")
print("         ##    VOICI LE JEU DU PENDU        ##")
print("         ##  programmé par Lea et Grégoire  ##")
print("         ##                                 ##")
print("         ##                                 ##")
print("         #####################################")
print("")
print("Version:2.1.1")
print("Nouveautés: -correction de fautes d'orthographe dans les print")
print("            -correction d'un bug logiciel(dans la gestion des caractéres non valide)")
print("            -graphisme amélioré")
print("            -correction de l'imposilité de gagner avec un mot qui comprend un tiret ")
print("            -majuscule")
print("Version:2.2.0")
print("Nouveautés: -ajout du pendu")
print("")
print("_______________________début du jeux_______________________________")


#  ********************** choix du mot
alphabet =["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

def choix_mot():
    with open("C:/Users/Gregoire/OneDrive/Bureau/NSI/python/pendu/liste_francais_modifiee_mot_entier.txt","r",encoding='utf8')as file : # ouvre le fichier
        mot = choice([m for m in file.readlines()]) # choisi un mot au hasard
    return mot

def formate_mot(mot):
    mot = mot.strip('\n''') # .replace('\n','') # supprimer les retour a la ligne et les espaces apres et avant le mot
    mot = unidecode.unidecode(mot)
    mot=mot.upper() # converti les minuscule en majuscule contraire 
    mot = list(mot) # converti le mot en liste
    return mot

mot = formate_mot(choix_mot()) # deuxieme mode str(input("quel est le mot ="))

# *********************** initialisatin des variables
longeur_du_mot = len(mot) 
lettre_deja_dit=[] # crée une liste vide
lettre_non_valide=[]
compteur_reusite = 0
compteur_faute = 0


# ****************************

def mot_afficher_fonction(longeur_du_mot):
    mot_afficher = []
    for i in range(0,longeur_du_mot): mot_afficher.append("_") # mot a afficher de base
    if  "-" in mot:
        rang = mot.index("-") # recupere le rang du tiret dans le mot
        del mot_afficher[rang] # supprime le tiret bas dans le mot afficher
        mot_afficher.insert(rang,"-") # le remplace par la tiret haut
        compteur_reusite += 1
    return mot_afficher
mot_afficher = mot_afficher_fonction(longeur_du_mot) # il faut absolument le créer car il va etre modifié après

# ********************** affichage                     

def affichage(compteur_faute):
    if compteur_faute==0:
        print("")
        print("")
        print("")
        print("")
        print("")
        print("______________________")
    if compteur_faute==1:  
        print("")
        print("|")
        print("|")
        print("|")
        print("|")
        print("|")
        print("|______________________")
    if compteur_faute==2:  
        print("_____________")
        print("| /           ")
        print("|/           ")
        print("|")
        print("|")
        print("|")
        print("|______________________")
    if compteur_faute==3:  
        print("_____________")
        print("| /          | ")
        print("|/           0")
        print("|")
        print("|")
        print("|")
        print("|______________________")
    if compteur_faute==4:  
        print("_____________")
        print("| /          | ")
        print("|/           0")
        print("|            |")
        print("|")
        print("|")
        print("|______________________")
    if compteur_faute==5:  
        print("_____________")
        print("| /          | ")
        print("|/          _0_")
        print("|            |")
        print("|")
        print("|")
        print("|______________________")
    if compteur_faute==6:  
        print("_____________")
        print("| /          | ")
        print("|/          _0_")
        print("|            |")
        print("|           / \\")
        print("|")
        print("|______________________") 



# ************************** boucle du jeux

while True:
    # graphique =
    print("")
    print("Voici le mot" ," ".join(mot_afficher)) # join convertit en chaine de caractere
    print("Ces lettres sont déjà dites : {",",".join(lettre_deja_dit),"}")
    print("Ces lettres ne sont pas dans le mot : {",",".join(lettre_non_valide),"}")
    print("Vous avez déjà fait",compteur_faute,"faute, à 6 fautes vous aurez perdu !!!" )
    affichage(compteur_faute) # le pendu
    print("")

    # demander un caractere
    lettre = str(input("Rentrez un caractère = ")) # demande une lettre et recommencer si la lettre n'est pas valide.
    lettre=lettre.upper() # converti en majuscule

    # test si le caractere entre est valide =
    while True:
        if lettre in lettre_deja_dit:
            print("    le caractere n'est pas valide car il a déja été dit")
            lettre = str(input("rentrez une autre lettre = ")) # demande une lettre
            lettre=lettre.upper()
        elif lettre not in alphabet:
            print("    le caractere n'est pas valide car il n'appartient pas à l'alphabet.")
            lettre = str(input("rentrez une autre lettre = ")) # demande une lettre
            lettre=lettre.upper()
        else:
            break

    lettre_deja_dit.append(lettre) # ajoute la lettre aux lettres deja dit.

    # test lettre dans le mot ou non. =
    test_faute = True
    for i in range(0,longeur_du_mot):
        if  lettre == mot[i]:
            del mot_afficher[i] # supprime le tiret dans le mot afficher
            mot_afficher.insert(i,lettre) # le remplace par la lettre
            compteur_reusite += 1
            test_faute = False

    if test_faute:
        print("la lettre n'est pas dans le mot")
        compteur_faute += 1
        lettre_non_valide.append(lettre)

    # test gagner/perdu et affichage  =
    if compteur_faute == 6:
        print("______________________perdu_________________________")
        affichage(compteur_faute)
        print("")
        print("le mot était","".join(mot))
        print("_________________________________________")
        break

    if compteur_reusite == longeur_du_mot:
        print("voici le mot" ,"".join(mot)) # convertie le mot en chaine de caractere en plus de l'afficher
        print("__________________ vous avez gagné !!! ___________________")
        print("")
        break # stoppe le jeux

#  *********************************