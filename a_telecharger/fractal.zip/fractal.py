from turtle import *



def motif1(taille):
    forward(taille)
    left(60)
    forward(taille)
    right(120)
    forward(taille)
    left(60)
    forward(taille)

def courbe(longueur,niveau,motif):
    if niveau == 1:
        motif(longueur)
    else:
        longueur = longueur/3
        niveau -=1
        courbe(longueur, niveau, motif)
        left(60)
        courbe(longueur, niveau, motif)
        right(120)
        courbe(longueur, niveau, motif)
        left(60)
        courbe(longueur, niveau, motif)

def figure(longueur,niveau,motif):
    for i in range(6):
        courbe(longueur,niveau,motif)
        left(60)

if __name__ == "__main__":
    penup()
    goto(0,0)
    pendown()
    speed(0)
    ht() # cache la tortue
    width(3)
    figure(50,3,motif1)
    fin=input("toucher entré pour quitter")
    
