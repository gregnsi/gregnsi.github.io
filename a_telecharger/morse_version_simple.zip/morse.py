# Créé par Gregoire, le 18/08/2022 en Python 3.7

morse = ["._ ","_...","_._.","_..",".",".._.","_ _.","....","..","._ _ _","_._","._..","_ _","_.","_ _ _","._ _.","_ _._","._.","...","_",".._","..._","._ _","_.._","_._ _","_ _..","","\n"]
alphabet =["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"," ","\n"]
liste_decode = []

fichier_code=str(input("rentré votre mot a crypté ="))

list_code = list(fichier_code)
for x in range(0,len(list_code)): # len = longueur liste code
    caractere = list_code[x]
    rang = alphabet.index(caractere) # donne le numero dans l'alphabet du caractere
    liste_decode.append(morse[rang]) # remplie la liste_decode, vide par le caractere morse au rang donné
chaine_decode = "\\".join(liste_decode)
print(chaine_decode)