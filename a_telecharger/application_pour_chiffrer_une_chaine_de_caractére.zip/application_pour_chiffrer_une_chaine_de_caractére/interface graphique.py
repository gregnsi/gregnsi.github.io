from code_V3 import *
import tkinter as tk
import tkinter.messagebox as messagebox
import pyperclip  # pour enregistrer dans le presse papier
import tkinter.simpledialog as sd     # pour demander le décalage pour le code césar


def presse_papier():
    pyperclip.copy(texte_sortie.cget('text'))  # enregistrer dans le presse papier
    messagebox.showinfo("Success", "Traduction copiée dans le presse papier !")


# Définition de la fonction qui sera exécutée lorsqu'on cliquera sur le bouton "Effacer"
def effacer():
    texte_entree.delete(0, tk.END)
    texte_sortie.config(text="")


def tk_morse_decode():
    texte_sortie.config(text=morse_decode(texte_entree.get()))
    if "caractére inconnu" in morse_decode(texte_entree.get()):
        messagebox.showerror("Erreur", "Vous devez rentrer une chaine de caractère en morse avec '.' pour les TI '-' pour les TA\n Et '/' comme séparateur pour les lettres et '//' pour les mots")

def tk_cesar():
    decalage = int(sd.askstring("Entrer une valeur", "Veuillez entrer le décalage(nombre entre -25 et 25):"))
    if decalage:
        # la fonction est exécutée seulement si l'utilisateur a saisi une valeur
        texte_sortie.config(text = cesar(texte_entree.get(),decalage))


def tk_vigenere(sens):
    cle = sd.askstring("Entrer une clé", "Veuillez entrer une cle de chiffrement/déchiffrement:")
    if cle:
        texte_sortie.config(text =vigenere(texte_entree.get(),cle,sens))


# Création de la fenêtre principale
fenetre = tk.Tk()
fenetre.title("Code")
fenetre.geometry('500x460')  

text_label = tk.Label(fenetre, text="Entrer le  texte a coder ou decoder :",font=("Times New Roman", 14),)
text_label.pack()

# Création de la zone de texte d'entrée
texte_entree = tk.Entry(fenetre,font=("Arial", 14),)
texte_entree.pack()

frame = tk.Frame(fenetre)
frame.pack(pady=5)

# Création de la zone de texte de sortie
texte_sortie = tk.Label(fenetre,font=("Times New Roman", 14,"bold"),fg="red")
texte_sortie.pack()

frame = tk.Frame(fenetre)
frame.pack(pady=5)

bouton_code_morse = tk.Button(fenetre, text="Morse", command=lambda:texte_sortie.config(text = morse_code(texte_entree.get())),bd=4, highlightthickness=2, bg="light gray",width=20)
bouton_code_morse.pack()

bouton_decode_morse = tk.Button(fenetre, text="Décoder morse", command=tk_morse_decode ,bd=4, highlightthickness=2, bg="light gray",width=20)
bouton_decode_morse.pack()

frame = tk.Frame(fenetre)
frame.pack(pady=5)

bouton_cesar = tk.Button(fenetre, text="Cesar", command=tk_cesar,bd=4, highlightthickness=2, bg="light gray",width=20)
bouton_cesar.pack()

frame = tk.Frame(fenetre)
frame.pack(pady=5)

bouton_code_vigenere = tk.Button(fenetre, text="Coder Vigenère", command=lambda: tk_vigenere(1),bd=4, highlightthickness=2, bg="light gray",width=20)
bouton_code_vigenere.pack()

bouton_decode_vigenere = tk.Button(fenetre, text="Décoder Vigenère", command=lambda: tk_vigenere(-1),bd=4, highlightthickness=2, bg="light gray",width=20)
bouton_decode_vigenere.pack()

frame = tk.Frame(fenetre)
frame.pack(pady=5)

bouton_code_assci = tk.Button(fenetre, text="Coder ASCII", command=lambda: texte_sortie.config(text=ascii_code(texte_entree.get())),bd=4, highlightthickness=2, bg="light gray",width=20)
bouton_code_assci.pack()

bouton_decode_assci = tk.Button(fenetre, text="Décoder ASCII", command=lambda: texte_sortie.config(text=ascii_decode(texte_entree.get())),bd=4, highlightthickness=2, bg="light gray",width=20)
bouton_decode_assci.pack()

frame = tk.Frame(fenetre)
frame.pack(pady=5)

# Création du bouton "Effacer"
bouton_effacer = tk.Button(fenetre, text="Effacer", command=effacer,bd=4, highlightthickness=2, bg="light gray",width=30)
bouton_effacer.pack()

copier_button = tk.Button(fenetre, text="Copier dans le presse papier", command=presse_papier,bd=4, highlightthickness=2, bg="gray",width=30)
copier_button.pack()

# Lancement de la boucle principale
fenetre.mainloop()