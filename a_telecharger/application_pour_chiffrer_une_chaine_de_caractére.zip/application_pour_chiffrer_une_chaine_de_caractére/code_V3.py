morse = {
        "a":".-",
        "b":"-...",
        "c":"-.-.",
        "d":"-..",
        "e":".",
        "f":"..-.",
        "g":"--.",
        "h":"....",
        "i":"..",
        "j":".---",
        "k":"-.-",
        "l":".-..",
        "m":"--",
        "n":"-.",
        "o":"---",
        "p":".--.",
        "q":"-.-",
        "r":".-.",
        "s":"...",
        "t":"-",
        "u":"..-",
        "v":"...-",
        "w":".--",
        "x":"-..-",
        "y":"-.--",
        "z":"--..",
        '1': '.----',
        '2': '..---',
        '3': '...--',
        '4': '....-',
        '5': '.....',
        '6': '-....',
        '7': '--...',
        '8': '---..',
        '9': '----.',
        '0': '-----',
        " ":"",
        "\n":"\n"
        }

alphabet=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]

def formate(chaine):
        """ supprime les accents d'une chaine """
        liste=list(chaine.lower().strip()) # met en minuscule et enléve les espaces au début et a la fin.
        accents = { 'à':"a",
                    'ã':"a",
                    'á':'â',
                    'é':"e",
                    'è':"e",
                    'ê':"e", 
                    'ë':"e",
                    'î':"i",
                    'ï':"i",
                    'ù':"u",
                    'ü':"u",
                    'û':"u",
                    'ô':"o",
                    'ö':"o"
                    }
        for i in range(len(liste)):
            liste[i]=accents.get(liste[i],liste[i])
        return "".join(liste)   # retransforme en chaine


def key(v,dico):
    """ return la clé d'un dictionnaire en fonction de la valeur """ 
    for (k, val) in dico.items():   # items return une liste de pair clé/dictionnaire 
        if v == val: 
            return k
    return( " caractére inconnu: " + str(v))


def morse_code(chaine):
    """ rentré une chaine et return une chaine en morse """
    liste = list(formate(chaine))  # convertie en minuscule et en liste et enléve les espace au début et a la fin 
    for i in range(len(liste)):
        liste[i]=morse.get(liste[i]," [caractére inconnu: " + liste[i] +"] ")    # parcours la liste et remplace les element par le morse dans le dictionnaire 
    return  "/".join(liste)      # transforme en chaine de caractere avec "/"  le séparateur



def morse_decode(chaine):
    liste=formate(chaine).split("/")   # transforme en liste en coupant a chaque "/" 
    for i in range(len(liste)):
        liste[i]=key(liste[i],morse)
    return "".join(liste)


def test_morse(chaine):
    if "/"  in chaine:
        return True
    return False 

def cesar(chaine,decalage:int):
    """rentré une chaine et un decalage compris entre 25 et -25 return une chaine"""
    liste=list(formate(chaine))
    for i in range(len(liste)):
        if liste[i]==" ":
            liste[i]=" "
        elif liste[i] not in alphabet:
            liste[i]=" [caractére inconnu: " + liste[i]+"] "
        else:    
            rang = alphabet.index(liste[i]) # donne l'indice dans l'alphabet de liste[i]
            nouveau_rang = rang+decalage
            if nouveau_rang>=26:
                nouveau_rang=nouveau_rang - 26   
            liste[i]=alphabet[nouveau_rang]
    return "".join(liste)    # transforme en chaine de caractére



 
                

def vigenere(chaine,cle,sens=1):  # sens  = 1  pour coder et sens = -1 pour decoder
    """rentré une chaine et une cle ainsi que le sens (1 ou -1) pour coder ou decoder, return une chaine"""
    print("vigenere")
    liste = list(formate(chaine))
    valeur_cle = -1

    for i in range(len(liste)):
        if liste[i]==" ":
            liste[i]=" "
        else:
            valeur_cle += 1
            if valeur_cle == len(cle): 
                valeur_cle = 0
            lette_de_decalage = cle[valeur_cle]
            decalage = (alphabet.index(lette_de_decalage))*sens

            if liste[i] not in alphabet:
                liste[i]= " [caractére inconnu: " + liste[i]+"] "
                print("erreur")
            else:
                rang = alphabet.index(liste[i]) # donne l'indice dans l'alphabet de liste[i]
                nouveau_rang = rang+decalage
                if nouveau_rang>=26:
                    nouveau_rang=nouveau_rang - 26   
                liste[i]=alphabet[nouveau_rang]
    return "".join(liste)    # transforme en chaine de caractére  


def ascii_code(chaine):
    chaine=chaine.strip()  # convertie en chaine sans les espaces au début et a la fin, on peut garder les majuscule et les caractéres accentué. 
    chaine2=""
    for i in chaine:
        chaine2+=" "+str(ord(i))
    return chaine2


def ascii_decode(chaine):
    liste=chaine.strip().split(" ")
    chaine=""
    try:
        for i in liste:
            chaine+=chr(int(i))
    except:  return "entrée incorrecte"      
    return chaine


# print(vigenere("acedf@d","bc",-1))

# if __name__ == "__main__":    # possibilté d'utiliser des fichiers
#     # entré
#     fichier_origine = open("CHEMIN D'ACCES","r")
#     entre=fichier_origine.read()
#     fichier_origine.close()


#     if test_morse(entre):
#         sortie=morse_decode(entre)
#     else: 
#         sortie=morse_code(entre)

#     # sortie
#     print(sortie)
#     fichier_code = open("CHEMIN D'ACCES","w")
#     fichier_code.write("\ntexte convertie:\n" + sortie)
#     fichier_code.close()